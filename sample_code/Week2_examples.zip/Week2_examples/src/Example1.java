
public class Example1 {

	public static void main(String[] args) {
		//Location of interest given as a string variable
		String loc1 = "UCSB";
		
		//The latitude of location 1 is given as a double variable
		double lat1 = 34.4139;
		
		//The longitude of location 1 is given as a double variable
		double lon1 = -119.8489;
		
		// A print statement is used to combine our three variables
		
		System.out.print(loc1 + " is located at " + 
						 lat1 + " degress latitude and " + 
						 lon1 + " degrees longitude.");

	}

}
