public class Human {
	
	public String name;
	private boolean belief = false;
	private Question q;
	
	public Human(String name, Question q) {
		this.name = name;
		this.q = q;
	}
	
	public boolean getBelief() { 
		return belief;	
	}
	
	public String getName() { 
		return name;	
	}
	
	public void debate() {
		
		q.setState(!q.getState());
		
		if(getBelief() != q.getState())
			belief = q.getState();
	}
	
	public String toString() {
		return this.name + " believes " + getBelief();
		
	}
}
