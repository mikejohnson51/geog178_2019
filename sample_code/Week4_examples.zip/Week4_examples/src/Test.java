public class Test {

	public static void main(String[] args) {
		
		Question toBe = new Question(3, false);
			System.out.println(toBe.toString());
		
		Human h1 = new Human("Jack", toBe);
			System.out.println(h1.toString() + "\n");
	
		while(!toBe.checkInsanity()) {
			System.out.println("DEBATE!!");
				h1.debate();
			System.out.println(toBe.toString());
			System.out.println(h1.toString());
			System.out.println("How many more debates?: " +toBe.getLifetime() + "\n");
		}
		
		System.out.println("DEBATE!!");
		h1.debate();
		System.out.println(toBe.toString());
		System.out.println(h1.toString());
		System.out.println("How many more debates?: " +toBe.getLifetime() + "\n");
		
	}


}