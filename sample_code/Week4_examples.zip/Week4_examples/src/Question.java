public class Question {
	
	private int lifetime;
	private boolean state; 
	
	public Question(int l, boolean b) {
		this.lifetime = l;
		this.state = b;
	}
	
	public int getLifetime() {
		return lifetime;
	}
	
	public boolean getState() {
		return state;
	}
	
	public void setState(boolean state) { 
		this.lifetime = lifetime - 1;
		this.state = state;
	}

	public boolean checkInsanity() { 
		return lifetime <= 0;
	}
	
	public String toString() {
		if(getState()) 
			return "the answer is to be";
		else
			return "the answer is not to be";	
	}
}