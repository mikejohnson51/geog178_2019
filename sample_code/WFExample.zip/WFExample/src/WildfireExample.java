import java.util.ArrayList;
import java.util.Iterator;


public class WildfireExample {
	static int trueCount = 0;
	
    public static void main(String[] args){
        WildfireModel wfm = new WildfireModel(200);
        //System.out.println(wfm.getBuildings());
        
        double hx, hy, lx, ly;
        hx = hy = Double.MIN_VALUE;
        lx = ly = Double.MAX_VALUE;
        Iterator<point> fireiterator = wfm.getWilfFirePolygon().iterator();
     
        while(fireiterator.hasNext()){ // has.Next Returns true if the iteration has more elements
            point edge = fireiterator.next(); // next Returns the next element
            hx = Math.max(hx, edge.getX());
            //System.out.println(edge.getX());
            hy = Math.max(hy, edge.getY());    
            lx = Math.min(lx, edge.getX());
            ly = Math.min(ly, edge.getY());    
        }
        BoundingBox bb = new BoundingBox(new point(lx, hy), new point(hx, ly));
        System.out.println("\nThe Bounding Box is: " + bb.toString());
       
        Iterator<point> Biterator = wfm.getBuildings().iterator();
         
        while(Biterator.hasNext()){
            point building = Biterator.next();
            boolean test = bb.isInside(building);
            //System.out.println("This building is in the BB: " + test);
            
            
            if (test == true) trueCount = trueCount +1;
        }
        
        System.out.println();
        System.out.println(trueCount + " buildings are in the Wildfire bounding box!!");
    }
}
