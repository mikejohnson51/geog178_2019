import java.util.ArrayList;

public class WildfireModel {

	// Arraylists of points
	private ArrayList<point> polypoints;
	private ArrayList<point> building;
	
	public WildfireModel(int numberOfBuildings) {
		polypoints = new ArrayList<point>();
		building = new ArrayList<point>();
		
		polypoints.add(new point(100,200));
		polypoints.add(new point(180,170));
		polypoints.add(new point(220,110));
		polypoints.add(new point(290,100));
		polypoints.add(new point(330,140));
		polypoints.add(new point(350,190));
		polypoints.add(new point(415,220));
		polypoints.add(new point(325,210));
		polypoints.add(new point(190,220));
		polypoints.add(new point(100,200));
		
		// Create some random coordinates for buildings
		for(int i=0; i<numberOfBuildings; i++){
			building.add(new point((int)(Math.random()*450)+10,(int)(Math.random()*450)+10));
		}
		
    }
	
	// Returns the list of points forming the wildfire polygon
	public ArrayList<point> getWilfFirePolygon(){
		return polypoints;
	}
	
	// Returns the list of buildings
	public ArrayList<point> getBuildings(){
		return building;
	}
	
	
}
