
public class BoundingBox {
		double xmax, xmin, ymax, ymin;
		
		
		public BoundingBox(point U, point L) {
			this.xmax = Math.max(U.x, L.x);
			this.xmin = Math.min(U.x, L.x);
			this.ymax = Math.max(U.y, L.y);
			this.ymin = Math.min(U.y, L.y);
		}
		
		boolean isInside(point z) {
			if (   z.x < xmax 
				&& z.x > xmin 
				&& z.y < ymax
				&& z.y > ymin) return true;
			else return false;
		}
		
		public double area() {
			return (xmax-xmin) * (ymax-ymin);
		}
	

	public String toString(){
		return "The Upper Point: ("+xmin+", "+ymax+"), and the Lower Point: ("+xmax+", "+ymin+")";
	}
}